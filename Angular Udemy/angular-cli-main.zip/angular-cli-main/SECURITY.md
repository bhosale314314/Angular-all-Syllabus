To report vulnerabilities in Angular itself, email us at security@angular.io.

For more information on Angular's security policy visit: https://angular.io/guide/security

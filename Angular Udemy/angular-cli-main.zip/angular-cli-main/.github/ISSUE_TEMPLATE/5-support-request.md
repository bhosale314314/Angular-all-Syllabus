---
name: '❓ Support request'
about: Questions and requests for support
---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please do not file questions or support requests on the GitHub issues tracker.

You can get your questions answered using other communication channels. Please see:
https://github.com/angular/angular-cli/blob/main/CONTRIBUTING.md#question

Thank you!

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑
